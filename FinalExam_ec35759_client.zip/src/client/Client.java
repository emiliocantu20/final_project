package client;

/**  EE422C Final Project submission by
 ** Replace <...> with your actual data.
 **  <Emilio Cantu>
 **  <ec35759>
 **  <16295>
 **  Spring 2020
 **/

import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.lang.Thread;
import java.net.Socket;
import java.io.*;
import java.net.*;

public class Client extends Application { 

	//NOTE: executable jar
	private clientController controller;
	private String username;
	private int port = 5555;
	private static String ip = "localhost";
	public String serverData = "";
	public String clientData = "";
	public BufferedReader fromServer;
	public OutputStreamWriter outStream;
	public PrintWriter toServer; 
	private Scanner consoleInput = new Scanner(System.in);

	@Override
	public void start(Stage primaryStage) {
		try {
			 
			
			FXMLLoader fxmlLoader = new FXMLLoader();
			System.out.println(getClass().getResource("control_clientScene.fxml"));
			Parent root = fxmlLoader.load(getClass().getResource("control_clientScene.fxml").openStream());
			controller = fxmlLoader.getController();
			System.out.println(getClass().getResource("control_clientScene.fxml"));
			primaryStage.setTitle("Customer");        
			primaryStage.setScene(new Scene(root, 700, 600));        
			primaryStage.show();
			controller.myClient = this;
			controller.initialize();
			controller.signOutButton.setOnAction((event) -> {
		          System.exit(0);
		        });
			controller.bidButton.setOnAction((event) -> {
	           String inputBid = controller.bidToProduct();
	           toServer.println(inputBid);
	            System.out.println("Sent " + inputBid);
	        });
			setUpNetworking();

		} catch(Exception e) {
			e.printStackTrace();
				
		}
	}

	public void setUpNetworking() throws Exception {
	    
		System.out.println("Connecting...");
		@SuppressWarnings("resource")
	    Socket socket = new Socket(ip, port);
	    System.out.println("[SERVER]: " + socket);
	    outStream = new OutputStreamWriter(socket.getOutputStream()); 
		toServer = new PrintWriter(outStream, true); 
		fromServer = new BufferedReader(new InputStreamReader(socket.getInputStream()));
	    System.out.println("Sending data to the Server..." );
	  	toServer.println("Connected.");								//SEND DATA
	    System.out.println("Data sent.");							
	    System.out.println("[SERVER]: "); 
	  	      
	     
	    Thread read = new Thread(new Runnable() {
	      @Override
	      public void run() {
	        synchronized(serverData) {
	        try {
	        	String sdata = fromServer.readLine();
	         while (sdata.equals(null)) { 	
	        	//serverData = fromServer.readLine(); 
	        	if(serverData.equals(null)) {
	        		break;
	        	}
	        	if(serverData.equals("close")) {
	        		socket.close();
	        		break;
	        	}
	        	else {
	        	controller.consoleOutput.setText(sdata);
	  	        System.out.println("[SERVER]: " + serverData);
	  	        processData(serverData); 
	  	        synchronized(clientData) {
	  	        	
	  	        }
	        	}
	         }
	        	
	          
	          
	        } catch (Exception e) {
	          e.printStackTrace();
	        }
	       }
	      }
	    });
	    
	    Thread write = new Thread(new Runnable() {
	      @Override
	      public void run() {
	    	  synchronized(serverData) {
	    	   synchronized(clientData) {
	    		   while (controller.bidButton.isPressed()) {
	    			   System.out.println("Sending data to the Server..." );
	    			   //toServer.println(clientData);								//SEND DATA
	    			   System.out.println("Data sent.");
	    			   
	        	}
	    	  }
	        }
	      }
	    });
	    
	    read.start();
	    write.start();
	    
	    read.join();
	    write.join();
	  }
	  public Client() {
		  
	  }
	  
      public Client(String username, int port) {
    	  this.username = username;
    	  this.port = port;
      }	
      
	  public String getUsername() {
		  return username;
	  }
	
	  public void setUsername(String s) {
		  username = s;
	  }
	
	  protected void processData(String input) {
		  return;
	  }
	
	
	public static void main(String[] args) {
		launch(args);
	}
}

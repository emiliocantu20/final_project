package client;

/**  EE422C Final Project submission by
 ** Replace <...> with your actual data.
 **  <Emilio Cantu>
 **  <ec35759>
 **  <16295>
 **  Spring 2020
 **/

import java.util.Map;
import java.util.Map.Entry;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.Thread;
import java.net.Socket;
import java.io.*;
import java.net.*;

public class loginController{ //extends Application {
	Client myClient;
	loginController controller;
    ObjectInputStream reader;
    ObjectOutputStream writer;
    
    public Label Title;
    public Label username;
    public Label password;
    public TextField userInput;
    public Button logIn;
    
    public void ClientLogIn() {
    	
    }
}

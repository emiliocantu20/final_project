package client;

/**  EE422C Final Project submission by
 ** Replace <...> with your actual data.
 **  <Emilio Cantu>
 **  <ec35759>
 **  <16295>
 **  Spring 2020
 **/

import java.util.Map;
import java.util.Map.Entry;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;
import javafx.scene.control.Spinner;
import javafx.scene.control.SpinnerValueFactory;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.lang.Thread;
import java.net.Socket;
import java.io.*;
import java.net.*;

public class clientController{ 

	//clientController controller;
	Client myClient;
    ObjectInputStream reader;
    ObjectOutputStream writer;
    //Client client;
    
    public GridPane productBox = new GridPane();
    public TextArea consoleOutput = new TextArea();
    public ChoiceBox<Object> list = new ChoiceBox<Object>();
    public Label bidPrice;
    public Label shipping;
    public Label currentPrice;
    public Label dollar1;
    public Label dollar2;
    public Spinner<Double> yourPrice;
    public TextField priceBox = new TextField();
    public Button bidButton;
    public Button buyButton;
    public Button signOutButton;
    public Button historyButton;
    public PrintStream ps;
    
    public void initialize() {
    	
    	//configure the console to the TestArea
    	ps = new PrintStream(new Console(consoleOutput)) ;
    	
    	//configure Spinner to allow double values for the bidding
    	SpinnerValueFactory<Double> bidValueFactory = new SpinnerValueFactory.DoubleSpinnerValueFactory(0, 999999999, 0, 0.5);
    	this.yourPrice.setValueFactory(bidValueFactory);
    	yourPrice.setEditable(true);
    }
    public String bidToProduct() {
    	String dataBid = yourPrice.getValue().toString();
    	return dataBid;										//send to server
    	
    }
    public void setClientNetwork() {
    	
    }  
    public void signOut() {
	   System.exit(0);       
   }
     
    ///**this piece was obatined from StackOverflow:
    public class Console extends OutputStream {
        private TextArea console;

        public Console(TextArea console) {
            this.console = console;
        }
        public void appendText(String valueOf) {
            Platform.runLater(() -> console.appendText(valueOf));
        }
        public void write(int b) throws IOException {
            appendText(String.valueOf((char)b));
        }
    }
    ///////^^^^^^^^ This piece is from StackOverflow
}


package server;

/**  EE422C Final Project submission by
 ** Replace <...> with your actual data.
 **  <Emilio Cantu>
 **  <ec35759>
 **  <16295>
 **  Spring 2020
 **/

import java.net.ServerSocket;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.lang.Thread;
import java.net.Socket;
import java.io.*;
import java.net.*;

public class Server extends Observable {

    static ServerSocket server;
    int port = 5555;
    private String serverData = "";
    private String clientData = "";
    private static ArrayList<Product> catalogue = new ArrayList<>();
    private static HashMap<String,ClientHandler> clients = new HashMap<>();
    private Scanner sc;
    
    public static void main (String [] args) {
        Server server = new Server(5555);		//change later
        server.writeCatalogue();
        server.printCat();
        server.SetupNetwork();
    } 
 
    private void printCat() {
    	for(int i = 0; i < catalogue.size(); i++) {
    		System.out.print(catalogue.get(i).getID() +" ");
    		System.out.print(catalogue.get(i).getName()+" ");
    		System.out.print(catalogue.get(i).getStartPrice()+" ");
    		System.out.println(catalogue.get(i).getBuyPrice());
    	}
    }
    private void writeCatalogue() {
		try {
			sc = new Scanner(new File("catalogue.txt"));
			while(sc.hasNextLine()) {
				//System.out.println(sc.next());
				Product temp = new Product();
				String id = sc.next();
				String name = sc.next();
				String startPrice = sc.next();
				String buy = sc.next();
				temp.setId(id);
				temp.setName(name);
				temp.setStartPrice(startPrice);
				temp.setBuyPrice(buy);
				catalogue.add(temp);
			}
			sc.close();
			for(int i = 0; i< catalogue.size(); i++) {
				System.out.println(catalogue.get(i).getName());
			}
				
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public Server(int port){
    	this.port = port;
    }
	
    private void SetupNetwork() {
        try { 
            	ServerSocket serverSock = new ServerSocket(port);
            	System.out.println("Server is ready!");
            
            	
            	while(true) {
            	System.out.println("Server waiting for client...");
                Socket clientSock = serverSock.accept();
                System.out.println("Server connected to Client: "+clientSock);											
                ClientHandler ch = new ClientHandler(this, clientSock);
                Thread t = new Thread(ch);
                t.start();
       	        }
        		
            
        } catch (IOException e) {
        	e.printStackTrace();
        	}
    }

    protected  String processRequest(String s) {
    	Double bet = 0.0;
    	try {
    	 bet = Double.parseDouble(s);
    	}catch(Exception e) {
    		return s;
    	}
    	if(bet > catalogue.get(0).getPrice() && !catalogue.get(0).isPurchased()) {		//change index later
    		if(bet == catalogue.get(0).getBuyPrice()){
    			catalogue.get(0).bought();
    			return "Your purchased was succesful!";
    		}
    		catalogue.get(0).setBid(bet);
    		Double newPrice = catalogue.get(0).getPrice();
    		return newPrice.toString();
    	
    	}
    	if(catalogue.get(0).isPurchased()) {
    		return "Item already purchased.";
    	}
    	else {
    		return "unable to make a bid.";
    	} 
 
    	
    } 

    class ClientHandler implements Runnable {
    	
    	private Server server;
    	private Socket clientSock;
    	private BufferedReader fromClient;
    	private OutputStreamWriter outStream;
    	private PrintWriter toClient;
    	private String clientName = "";
    	 
    	public ClientHandler(Server ss, Socket clientsoc) {
    		this.server = ss;
    		this.clientSock = clientsoc;
    		try {
				this.fromClient = new BufferedReader(new InputStreamReader(this.clientSock.getInputStream()));
				this.outStream = new OutputStreamWriter(this.clientSock.getOutputStream());
				this.toClient = new PrintWriter(outStream, true);
    		}catch (IOException e) { 
				e.printStackTrace();
			}   
    	}
    	
		@Override
		public void  run() {
		   synchronized(clientSock) {
		   boolean isOn = true;
		   boolean isName = false;
		   try { 
			//server.serverData = fromClient.readLine();
			   //!server.serverData.equals(null)
			while (true) {
				server.serverData = fromClient.readLine();
			 							//RECEIVE DATA
				if(server.serverData.equals(null)) {
					break;
				}
				
				else {
		      
              System.out.println("[CLIENT]: "+ server.serverData);
              server.clientData = processRequest(server.serverData);
              //server.clientData = server.serverData.toUpperCase();						//PROCESS REQUEST
     	      System.out.println("Sending data...");  
     	  	  toClient.println(server.clientData);									//SEND DATA
     	  	  System.out.println("Data sent.");
     	  	  
				}
		      } 
     	    
		   }catch(IOException e) {
				e.printStackTrace();
			}
		   
		}
	  }
    	
    }
}

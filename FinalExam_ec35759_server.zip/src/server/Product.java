package server;

/**  EE422C Final Project submission by
 ** Replace <...> with your actual data.
 **  <Emilio Cantu>
 **  <ec35759>
 **  <16295>
 **  Spring 2020
 **/	

import java.io.Serializable;
import java.util.Timer;

public class Product implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String name;
	private double startPrice;
	private double currentPrice;
	private int id;
	private double buyPrice;
	private Timer timer;
	private boolean isBuy = false;
	
	public Product () {
		
	}
	
	public Product(String name, double startPrice, int id) {
		this.name = name;
		this.startPrice = startPrice;
		this.id = id;
		this.currentPrice = startPrice;
	}
	
	
	public double getBuyPrice() {
		
		return buyPrice;
	}
	public double getStartPrice() {
		return startPrice;
	}
	public int getID() {
		return id;
	}
	public double getPrice() {
		return currentPrice;
	}
	public String getName() {
		return name;
	}
	public void setBid(double bid) {
		currentPrice = bid; 
	}
	public void setName(String s) {
		this.name = s;
	}
	public void setStartPrice(String s) {
		this.startPrice = Double.parseDouble(s);
		this.currentPrice = this.startPrice;
	}
	public void setId(String s) {
		this.id = Integer.parseInt(s);
	}
	public void setBuyPrice(String s) {
		this.buyPrice = Double.parseDouble(s);
	}
	public boolean isPurchased() {
		return isBuy;
	}
	public boolean bought() {
		isBuy = true;
		return isBuy;
	}
}
